import random

from fastapi.testclient import TestClient
from src.chess import app
import pytest

client = TestClient(app)


@pytest.fixture(autouse=True)
def reset_board():
    client.get("/reset")


def test_GivenPawnOnIntialLocaiton_WhenGettingPossibleMoves_ThenCanMoveStep():
    # Check the initial state of the chessboard
    col = random.randint(0, 7)
    response = client.get(f"/possibleMoves/{col}/1")

    possilbeMoves = response.json().get("possible_moves")
    assert set(possilbeMoves) == {f"{col}2", f"{col}3"}


def test_GivenBlackPawnOnIntialLocaiton_WhenGettingPossibleMoves_ThenCanMoveStep():
    response = client.get("/possibleMoves/0/6")
    possilbeMoves = response.json().get("possible_moves")
    assert set(possilbeMoves) == {"05", "04"}


def test_GivenPawnNotOnInitialLocation_WhenGettingPossibleMoves_ThenCanMoveOnlyOneStep():
    col = random.randint(0, 7)
    client.post(f"/move/0/1/{col}/4")

    response = client.get(f"/possibleMoves/{col}/4")

    possilbeMoves = response.json().get("possible_moves")
    assert set(possilbeMoves) == {f"{col}5"}


def test_GivenKnightOnRandomLocation_WhenGettingPossibleMoves_ThenCanMoveOnlyDiagonalyOnStepForward():
    col = 4
    row = 4
    move(col, row)

    response = client.get(f"/possibleMoves/{col}/{row}")

    possilbeMoves = response.json().get("possible_moves")
    assert f"{col + 1}{row + 2}" in set(possilbeMoves)


def move(col, row):
    client.post(f"/move/1/0/{col}/{row}")
