class Square:
    def __init__(self, col, row):
        self.col = col
        self.row = row
        self.check_bounds()

    def check_bounds(self):
        if not (0 <= self.col < 8 and 0 <= self.row < 8):
            raise ValueError("Square is out of bounds")

    def __str__(self):
        return f"{chr(self.col + ord('a'))}{self.row}"