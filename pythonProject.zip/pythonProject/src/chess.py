from fastapi import FastAPI

from src.ChessBoard import ChessBoard
from src.PossibleMovesAbaGanuv import calculate_move
from src.Square import Square

app = FastAPI()
chessboard = ChessBoard()

@app.get("/possibleMoves/{col}/{row}")
def get_possible_moves(col: int, row: int):
    square = Square(col, row)
    piece = chessboard.get_piece(square)
    possibleMoves = calculate_move(col, piece, row)
    return {"possible_moves": possibleMoves}

@app.post("/move/{from_col}/{from_row}/{to_col}/{to_row}")
def move(from_col: int, from_row: int, to_col: int, to_row: int):
    from_square = Square(from_col, from_row)
    to_square = Square(to_col, to_row)
    chessboard.move_piece(from_square, to_square)


@app.get("/reset")
def reset():
    pass


