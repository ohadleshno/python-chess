from src.Square import Square


class ChessBoard:
    def __init__(self):
        self.board = {}
        # Initialize the chessboard with pieces
        self.reset()

    def reset(self):
        self.board = {}
        pieces_order = [
            "Rook", "Knight", "Bishop", "Queen", "King", "Bishop", "Knight", "Rook"
        ]
        for row in range(8):
            for col in range(8):
                square = Square(col, row)
                if row == 1 or row == 6:
                    piece = "Pawn"
                elif row == 0 or row == 8:
                    if col < len(pieces_order):
                        piece = pieces_order[col]
                    else:
                        piece = None
                else:
                    piece = None
                if piece:
                    self.board[str(square)] = piece

    def get_piece(self, square):
        return self.board.get(str(square))

    def move_piece(self, from_square, to_square):
        piece = self.board.pop(str(from_square))
        self.board[str(to_square)] = piece
