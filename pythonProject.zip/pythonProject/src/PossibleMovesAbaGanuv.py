
WHITE_PAWN_INTIAL_LOCATION = 1

BLACK_PAWN_INTIAL_LOCATION = 6

def calculate_move(col, piece, row):
    if piece == "Pawn":
        possibleMoves = get_pawn_possible_moves(row, col)
    elif piece == "Knight":
        possibleMoves = get_Knight_possible_moves(row, col)
    return possibleMoves


def get_pawn_possible_moves(row: int, col: int):
    direction = -1 if row == BLACK_PAWN_INTIAL_LOCATION else 1
    possibleMoves = [f"{col}{row + direction}"]
    if row == BLACK_PAWN_INTIAL_LOCATION or row == WHITE_PAWN_INTIAL_LOCATION:
        possibleMoves.append(f"{col}{row + 2 * direction}")
    return possibleMoves


def get_Knight_possible_moves(row: int, col: int):
    return [f"{col + 1}{row + 2}"]
